<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Gestion de la FAQ</title>
        <link rel="stylesheet" href="../css/style.css">
    </head>
    <body>
        <div id="content" class="cadre">
        <?php 
            require './menuAdmin.php';
        ?>
        <div id="listeFAQ">
        <label>Liste des FAQ : </label>
        <select>
            <option>Création d'une nouvelle FAQ</option>
            <?php
            for ($i = 0; $i<10; $i++){
            echo '<option>' .
                'FAQ ' . $i .
            '</option>';
            }
            ?>
        </select>
        </div>
        
        <form class="cadre">
            <table id="tableFAQ">
                <tr>
                    <th id="tableLabel"></th>
                    <th id="tableValeur"></th>
                </tr>
                <tr>
                    <td>
                        
            <label>Titre :</label>
                    </td>
                    <td>
            <input type="text" name="titre" value="testPrenom"/>
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>Description :</label>
                    </td>
                    <td>
                        <textarea name="description" rows="5" style="width:100%;"></textarea>
                    </td>
                </tr>
            </table>
            <div id="boutons">
                <button class="btn-orange">Modifier</button>
                <button class="btn-orange">Supprimer</button>
                <br>
                <button class="btn-orange">Ajouter</button>
            </div>
        </form>
        </div>
    </body>
</html>
