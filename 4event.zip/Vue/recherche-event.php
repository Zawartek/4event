<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Recherche Evénément</title>
        <link href="./css/style.css" rel="stylesheet" media="all" type="text/css"> 
    </head>
    <body>
        <div id="content">
            <?php require("./header.php"); ?>
            Content
        </div>
        
        <div id="footer">
            
        </div>
    </body>
</html>